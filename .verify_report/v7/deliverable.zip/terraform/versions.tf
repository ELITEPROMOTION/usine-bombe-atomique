terraform {
  required_version = ">= 1.6.0"
  required_providers {
    aws    = { source = "hashicorp/aws",    version = "~> 5.60" }
    random = { source = "hashicorp/random", version = "~> 3.5"  }
  }
}

provider "aws" {
  region = var.region
  default_tags {
    tags = {
      Project = "projet"
      Managed = "terraform"
      Owner   = "Groupe Dendani"
    }
  }
}
