output "cluster_arn" {
  description = "ARN du cluster ECS"
  value       = aws_ecs_cluster.main.arn
}

output "log_group" {
  description = "Log group CloudWatch applicatif"
  value       = aws_cloudwatch_log_group.app.name
}
