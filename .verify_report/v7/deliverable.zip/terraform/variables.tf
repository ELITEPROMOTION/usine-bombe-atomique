variable "region" {
  description = "Region AWS"
  type        = string
  default     = "eu-west-3"
}

variable "project_name" {
  description = "Nom du projet (tag + prefix ressources)"
  type        = string
  default     = "projet"
}

variable "image_tag" {
  description = "Tag image container a deployer"
  type        = string
  default     = "latest"
}

variable "container_cpu" {
  type    = number
  default = 512
}

variable "container_memory" {
  type    = number
  default = 1024
}
