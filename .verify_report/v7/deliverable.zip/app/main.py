"""CRUD API - User."""
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

app = FastAPI(title="User API")

_store: dict[int, dict] = {}
_next_id: int = 1


class UserIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)


class UserOut(UserIn):
    id: int


@app.get("/health")
def health() -> dict:
    return {"status": "ok"}


@app.post("/users", response_model=UserOut, status_code=201)
def create(payload: UserIn) -> UserOut:
    global _next_id
    item = {"id": _next_id, **payload.model_dump()}
    _store[_next_id] = item
    _next_id += 1
    return UserOut(**item)


@app.get("/users", response_model=list[UserOut])
def list_all() -> list[UserOut]:
    return [UserOut(**v) for v in _store.values()]


@app.get("/users/{item_id}", response_model=UserOut)
def get_one(item_id: int) -> UserOut:
    item = _store.get(item_id)
    if item is None:
        raise HTTPException(404, "User not found")
    return UserOut(**item)


@app.put("/users/{item_id}", response_model=UserOut)
def update(item_id: int, payload: UserIn) -> UserOut:
    if item_id not in _store:
        raise HTTPException(404, "User not found")
    updated = {"id": item_id, **payload.model_dump()}
    _store[item_id] = updated
    return UserOut(**updated)


@app.delete("/users/{item_id}", status_code=204)
def delete(item_id: int) -> None:
    if item_id not in _store:
        raise HTTPException(404, "User not found")
    del _store[item_id]
