"""Tests CRUD User."""
from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)


def test_health() -> None:
    r = client.get("/health")
    assert r.status_code == 200
    assert r.json() == {"status": "ok"}


def test_crud_cycle() -> None:
    r = client.post("/users", json={"name": "alpha"})
    assert r.status_code == 201
    item = r.json()
    assert item["name"] == "alpha"
    item_id = item["id"]

    r = client.get(f"/users/{item_id}")
    assert r.status_code == 200

    r = client.put(f"/users/{item_id}", json={"name": "beta"})
    assert r.status_code == 200
    assert r.json()["name"] == "beta"

    r = client.get("/users")
    assert r.status_code == 200
    assert len(r.json()) >= 1

    r = client.delete(f"/users/{item_id}")
    assert r.status_code == 204

    r = client.get(f"/users/{item_id}")
    assert r.status_code == 404
